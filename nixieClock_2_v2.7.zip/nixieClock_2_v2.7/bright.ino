void backlBrightTick() {
  if (BACKL_MODE == 0 && backlBrightTimer.isReady()) {
    if (backlMaxBright > 0) {
      if (backlBrightDirection) {
        if (!backlBrightFlag) {
          backlBrightFlag = true;
          backlBrightTimer.setInterval((float)BACKL_STEP / backlMaxBright / 2 * BACKL_TIME);
        }
        backlBrightCounter += BACKL_STEP;
        if (backlBrightCounter >= backlMaxBright) {
          backlBrightDirection = false;
          backlBrightCounter = backlMaxBright;
        }
      } else {
        backlBrightCounter -= BACKL_STEP;
        if (backlBrightCounter <= BACKL_MIN_BRIGHT) {
          backlBrightDirection = true;
          backlBrightCounter = BACKL_MIN_BRIGHT;
          backlBrightTimer.setInterval(BACKL_PAUSE);
          backlBrightFlag = false;
        }
      }
      setPWM(BACKL, getPWM_CRT(backlBrightCounter));
    } else {
      setPin(BACKL, 0);
    }
  }
}

void dotBrightTick() {
  if(dotMode==0) setPWM(DOT, 0);
  else if(dotMode==1) setPWM(DOT, dotMaxBright);
  else if(dotMode==2) {
    if (dotBrightFlag && dotBrightTimer.isReady()) {
      if (dotBrightDirection) {
        dotBrightCounter += dotBrightStep;
        if (dotBrightCounter >= dotMaxBright) {
          dotBrightDirection = false;
          dotBrightCounter = dotMaxBright;
        }
      }else{
        dotBrightCounter -= dotBrightStep;
        if (dotBrightCounter <= 0) {
          dotBrightDirection = true;
          dotBrightFlag = false;
          dotBrightCounter = 0;
        }
      }
      if (DOT_MODE==0){
        if(!dotBrightDirection)setPWM(DOT, dotMaxBright);
        else setPin(DOT, 0);
      }else if (DOT_MODE==1) setPWM(DOT, getPWM_CRT(dotBrightCounter));
    }
  }
}

void changeBright() {
#if (NIGHT_LIGHT == 1)
  // установка яркости всех светилок от времени суток
  if ( ((hrs >= NIGHT_START && hrs <= 23)
       || (hrs >= 0 && hrs < NIGHT_END)) && mode!=5 ) {
    indiMaxBright = INDI_BRIGHT_N;
    dotMaxBright = DOT_BRIGHT_N;
    backlMaxBright = BACKL_BRIGHT_N;
  } else {
    indiMaxBright = INDI_BRIGHT;
    dotMaxBright = DOT_BRIGHT;
    backlMaxBright = BACKL_BRIGHT;
  }
  for (byte i = 0; i < 4; i++) {
    indiDimm[i] = indiMaxBright;
  }

  dotBrightStep = ceil((float)dotMaxBright * 2 / DOT_TIME * DOT_TIMER);
  if (dotBrightStep == 0) dotBrightStep = 1;

  if (backlMaxBright > 0)
    backlBrightTimer.setInterval((float)BACKL_STEP / backlMaxBright / 2 * BACKL_TIME);
  indiBrightCounter = indiMaxBright;

  //change PWM to apply backlMaxBright in case of maximum bright mode
  if (BACKL_MODE == 1) setPWM(BACKL, backlMaxBright);
#endif
tickGen();
}

// мнеяем напряжение генератора в зависимости от количества зажжённых ламп 
void tickGen(){
  byte numOfLamps=(anodeStates[0]+anodeStates[1]+anodeStates[2]+anodeStates[3]);
  if(NIGHT_LIGHT==1 && (hrs >= NIGHT_START && hrs <= 23)
    || (hrs >= 0 && hrs < NIGHT_END) ) {
    switch(numOfLamps){
    case 0: DUTY=0; break;
    case 1: DUTY=DUTY_1_N; break;
    case 2: DUTY=DUTY_2_N; break;
    case 3: DUTY=DUTY_3_N; break;
    case 4: DUTY=DUTY_4_N; break;
    }
  }else{
    switch(numOfLamps){
    case 0: DUTY=0; break;
    case 1: DUTY=DUTY_1; break;
    case 2: DUTY=DUTY_2; break;
    case 3: DUTY=DUTY_3; break;
    case 4: DUTY=DUTY_4; break;
    }
  }
  setPWM(9, DUTY);  
}
