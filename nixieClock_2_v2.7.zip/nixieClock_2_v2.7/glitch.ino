void glitchTick() {
if(newGlitchFlag){
  glitchTimer.setInterval(300);
  if(glitchTimer.isReady()){
    anodeStates[0] = !anodeStates[0];
    anodeStates[1] = !anodeStates[1];
    anodeStates[2] = !anodeStates[2];
    anodeStates[3] = !anodeStates[3];
    tickGen();
    glitchCounter++;
  }
  if(glitchCounter>=6){
    newGlitchFlag=false;
    glitchCounter=0;
  }
}else{ 
    if (!glitchFlag && secs > 7 && secs < 55) {
      if (glitchTimer.isReady()) {
        glitchFlag = true;
        indiState = 0;
        glitchCounter = 0;
        glitchMax = random(2, 6);
        glitchIndic = random(0, 4);
        glitchDigitChance = random(0, 5);
        if(glitchDigitChance == 0){
          correctDigit = indiDigits[glitchIndic];
          do{glitchDigit = random(0, 10);}
          while(glitchDigit == correctDigit);
        }
        glitchTimer.setInterval(random(1, 10) * 20);
      }
    } else if (glitchFlag && glitchTimer.isReady()) {
      if(glitchDigitChance == 0){
        if(!indiState) indiDigits[glitchIndic] = glitchDigit;
        else indiDigits[glitchIndic] = correctDigit;
      }else{
        indiDimm[glitchIndic] = indiState * indiMaxBright;
      }
      indiState = !indiState;
      glitchTimer.setInterval(random(1, 10) * 20);
      glitchCounter++;
      if (glitchCounter > glitchMax) {
        glitchTimer.setInterval(random(GLITCH_MIN * 1000L, GLITCH_MAX * 1000L));
        glitchFlag = false;
        indiDimm[glitchIndic] = indiMaxBright;
      }
    }
  }
}
