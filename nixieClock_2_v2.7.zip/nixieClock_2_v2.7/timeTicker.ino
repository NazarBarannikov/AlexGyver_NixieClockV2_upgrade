byte minsCount = 0;
void calculateTime() {
  dotFlag = !dotFlag;
  tickGen();
  if (dotFlag) {
    dotBrightFlag = true;
    dotBrightDirection = true;
    dotBrightCounter = 0;
    secs++;
    if (secs > 59) {
      if(mode==0)newTimeFlag = true;   // флаг, что нужно поменять время
      secs = 0;
      mins++;
      minsCount++;
      if(mode==0 && alm_mode!=0 && alm_mins == mins && alm_hrs == hrs) { 
        mode=5; 
        changeBright();
      }

      if (minsCount >= 15) {            // каждые 15 мин
        minsCount = 0;
        DateTime now = rtc.now();       // синхронизация с RTC
        secs = now.second();
        mins = now.minute();
        hrs = now.hour();
        if(mode==0 && alm_mode!=0 && alm_mins == mins && alm_hrs == hrs) { 
          mode=5; 
          changeBright();
        }
      }

      if (mins % BURN_PERIOD == 0) burnIndicators();     // чистим чистим!

      
    }
    if (mins > 59) {
      mins = 0;
      hrs++;
      if (hrs > 23) hrs = 0;
      if(mode==0 && alm_mode!=0 && alm_mins == mins && alm_hrs == hrs) { 
        mode=5; 
        changeBright();
      }
      changeBright();
    }
    if (newTimeFlag) setNewTime();         // обновляем массив времени
  }  
}
