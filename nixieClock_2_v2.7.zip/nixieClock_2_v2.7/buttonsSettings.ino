void settingsTick() {
  if(mode==0){
    dotMode=2;
    if(!newTimeFlag && !glitchFlag && !newGlitchFlag){
        anodeStates[0] = 1;
        anodeStates[1] = 1;
        anodeStates[2] = 1;
        anodeStates[3] = 1;
        tickGen();
        sendTime(hrs, mins);
    }
  }
   
  else if(mode==1){
    dotMode=1;
    if (!dotFlag) {
        anodeStates[0] = 1;
        anodeStates[1] = 1;
        anodeStates[2] = 1;
        anodeStates[3] = 1;
        tickGen();
      }else if(!btnR.isHold() && !btnL.isHold()){
        if (!currentDigit) {
          anodeStates[0] = 0;
          anodeStates[1] = 0;
          tickGen();
        } else {
          anodeStates[2] = 0;
          anodeStates[3] = 0;
          tickGen();
        }
      }
     sendTime(changeHrs, changeMins);
     hrs = changeHrs;
     mins = changeMins;
     secs = 0;
  }

  else if(mode==2){
    dotMode=1;
    if (!dotFlag) {
        anodeStates[0] = 1;
        anodeStates[1] = 1;
        anodeStates[2] = 1;
        anodeStates[3] = 1;
        tickGen();
      }else if(!btnR.isHold() && !btnL.isHold()){
        if (!currentDigit) {
          anodeStates[0] = 0;
          anodeStates[1] = 0;
          tickGen();
        } else {
          anodeStates[2] = 0;
          anodeStates[3] = 0;
          tickGen();
        }
      }
     sendTime(changeHrs, changeMins);
     alm_hrs = changeHrs;
     alm_mins = changeMins;
  }

  else if(mode==3){
     dotMode=0;
     anodeStates[0] = 0;
     anodeStates[1] = 1;
     anodeStates[2] = 0;
     anodeStates[3] = 0;
     tickGen();
     sendTime(change_alm_mode, 00);
  }

  else if(mode==4){
    dotMode=0;
    char tmp=rtc.getTemperature();
    if(tmp<0){
      anodeStates[0] = 1;
      anodeStates[1] = 0;
      anodeStates[2] = 1;
      anodeStates[3] = 1;
      tickGen();  
    }else{
      anodeStates[0] = 0;
      anodeStates[1] = 0;
      anodeStates[2] = 1;
      anodeStates[3] = 1;
      tickGen();
    }
    sendTime(00, tmp);
  }

  else if(mode==5){
    dotMode=2;
    // мигать на будильнике 
    #if(BUZ_TYPE==0) 
    setPin(PIEZO, HIGH);//tone(PIEZO, 1000);
    #endif
    if(!dotFlag) {
      anodeStates[0] = 0;
      anodeStates[1] = 0;
      anodeStates[2] = 0;
      anodeStates[3] = 0;
      tickGen();
      #if(BUZ_TYPE==1)
      setPin(PIEZO, HIGH);//tone(PIEZO, 1000);
      #endif
    }else{
      anodeStates[0] = 1;
      anodeStates[1] = 1;
      anodeStates[2] = 1;
      anodeStates[3] = 1;
      tickGen();
      sendTime(hrs, mins);
      #if(BUZ_TYPE==1)
      setPin(PIEZO, LOW);//noTone(PIEZO);
      #endif
    }
  }

  else if(mode==6){
    dotMode=0;
    anodeStates[0] = 0;
    anodeStates[1] = 0;
    anodeStates[2] = 0;
    anodeStates[3] = 1;
    tickGen();
    sendTime(00, pointer);
  } 
}

void buttonsTick() {
  btnSet.tick();
  btnL.tick();
  btnR.tick();
  if (mode==1||mode==2) {
    if (btnR.isClick() || (btnR.isHold()&&buttonTimer.isReady())) {
      buttonTimer.reset();
      if (!currentDigit) {
        changeHrs++;
        if (changeHrs > 23) changeHrs = 0;
      } else {
        changeMins++;
        if (changeMins > 59) {
          changeMins = 0;
          changeHrs++;
          if (changeHrs > 23) changeHrs = 0;
        }
      }
      sendTime(changeHrs, changeMins);
    }
    if (btnL.isClick() || (btnL.isHold()&&buttonTimer.isReady())) {
      buttonTimer.reset();
      if (!currentDigit) {
        changeHrs--;
        if (changeHrs < 0) changeHrs = 23;
      } else {
        changeMins--;
        if (changeMins < 0) {
          changeMins = 59;
          changeHrs--;
          if (changeHrs < 0) changeHrs = 23;
        }
      }
      sendTime(changeHrs, changeMins);
    }
    if(btnL.isHolded());
    if(btnR.isHolded());

  }else if (mode==0) {
    // переключение эффектов цифр
    if (btnR.isClick()) {
      if (++FLIP_EFFECT >= FLIP_EFFECT_NUM) FLIP_EFFECT = 0;
      EEPROM.put(0, FLIP_EFFECT);
      flipTimer.setInterval(FLIP_SPEED[FLIP_EFFECT]);
      for (byte i = 0; i < 4; i++) {
        indiDimm[i] = indiMaxBright;
        anodeStates[i] = 1;
      }
      // показать эффект
      newTimeFlag = true;
      flipInit = false;
      for (byte i = 0; i < 4; i++) indiDigits[i] = FLIP_EFFECT;
    }

    // переключение эффектов подсветки
    if (btnL.isHolded()) {
      if (++BACKL_MODE >= 3) BACKL_MODE = 0;
      EEPROM.put(1, BACKL_MODE);
      if (BACKL_MODE == 1) {
        setPWM(BACKL, backlMaxBright);
      } else if (BACKL_MODE == 2) {
        setPin(BACKL, 0);
      }
    }

    // переключение глюков
    if (btnL.isClick()) {
      GLITCH_ALLOWED = !GLITCH_ALLOWED;
      EEPROM.put(2, GLITCH_ALLOWED);
      if(GLITCH_ALLOWED) newGlitchFlag = true; 
      else newGlitchFlag = false;
      glitchCounter=0;
    }
    
    // переключение режимов мигания точки
    if (btnR.isHolded()) {
      if (++DOT_MODE >= 2) DOT_MODE = 0;
      EEPROM.put(3, DOT_MODE);
    }

  }else if(mode==6){
    if(btnR.isClick())pointer++;
    if(btnL.isClick())pointer--;   
    if(pointer>4)pointer=0;
    if(pointer<0)pointer=4;
    if(btnL.isHolded());
    if(btnR.isHolded());

  }else if(mode==3){   
    if(btnR.isClick())change_alm_mode++;
    if(btnL.isClick())change_alm_mode--;
    if(change_alm_mode>2)change_alm_mode=0;
    if(change_alm_mode<0)change_alm_mode=2;
    if(btnL.isHolded());
    if(btnR.isHolded());
     
  }else if(mode==4){
    if(btnR.isClick());
    if(btnL.isClick());
    if(btnL.isHolded());
    if(btnR.isHolded());
  
  }else if(mode==5){
    if(btnSet.isClick()||btnL.isClick()||btnR.isClick()){
      if(alm_mode==1) {
        alm_mode=0;
        EEPROM.put(6, alm_mode);
        if(alm_mode != 0) setPin(LED, HIGH);
        else setPin(LED, LOW);
      }
      mode=0;
      newTimeFlag = false;
      flipInit = false;
      changeBright();
      setPin(PIEZO, LOW);//noTone(PIEZO);
    }
    if(btnL.isHolded());
    if(btnR.isHolded());  
  }
    

  if(btnSet.isHolded()){
    if(mode==0 && !newTimeFlag){
      mode=6;
      pointer=0;
    }
    else if(mode==1){
      rtc.adjust(DateTime(2019, 12, 05, changeHrs, changeMins, 0));
      mode=0;
      changeBright();
    }    
    else if(mode==2){
      alm_hrs = changeHrs;
      alm_mins = changeMins;
      EEPROM.put(4, alm_hrs);
      EEPROM.put(5, alm_mins);
      mode=0;
      changeBright();
    }
    else if(mode==3){
      alm_mode = change_alm_mode;
      EEPROM.put(6, alm_mode);
      if(alm_mode != 0) setPin(LED, HIGH);
      else setPin(LED, LOW);
      mode=0;
    }
    else if(mode==4) mode=0; 
  }
  
  if(btnSet.isClick()) {
    if(mode==1||mode==2) currentDigit = !currentDigit; // настройка времени
    else if(mode==6){
      switch(pointer){
        case 0:
        mode=0;
        break;
        case 1:
        mode=1;
        changeHrs=hrs;
        changeMins=mins;
        currentDigit = false;
        break;
        case 2:
        mode=2;
        changeHrs=alm_hrs;
        changeMins=alm_mins;
        currentDigit = false;
        break;
        case 3:
        mode=3;
        change_alm_mode=alm_mode;
        break;
        case 4:
        mode=4;
        break;
      }  
    }
  }
}
